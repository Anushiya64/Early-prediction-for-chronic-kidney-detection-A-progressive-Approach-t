# Early-predition-for-chronic-kidney-diease-detection-A-progressive-approach-to-health-management

video demonstration - https://youtu.be/eW0t9XxAxkc
